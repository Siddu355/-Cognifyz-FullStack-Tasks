import express from "express";
import path from "path";

const app = express();
const __dirname = path.resolve();

app.use(express.urlencoded({ extended: true }));

// EJS setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Temporary storage
let submittedData = [];

// Show form
app.get("/", (req, res) => {
  res.render("form", { error: null, success: null });
});

// Handle form submission
app.post("/submit", (req, res) => {
  const { name, email, age } = req.body;

  // Server-side validation
  if (!name || !email || !age) {
    return res.render("form", {
      error: "All fields are required!",
      success: null,
    });
  }

  if (age < 18) {
    return res.render("form", {
      error: "Age must be 18 or above!",
      success: null,
    });
  }

  // Store data
  submittedData.push({ name, email, age });

  res.render("form", {
    error: null,
    success: "Form submitted successfully!",
  });
});

// Server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
